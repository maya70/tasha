const defaultSettings = require('./karma.defaults.js');

module.exports = function (config) {
  config.set(defaultSettings);
};